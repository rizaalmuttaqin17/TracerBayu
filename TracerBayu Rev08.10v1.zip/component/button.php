<?php 
    if($rowTotal == $kuisioner['idKuisioner']){
    ?>
        <button class="btn btn-primary font-weight-bold">Simpan dan lanjut</button>
    <?php
    }else{
   ?>
    <button class="btn btn-primary font-weight-bold">Simpan dan lanjut</button>
<?php
    }
?>